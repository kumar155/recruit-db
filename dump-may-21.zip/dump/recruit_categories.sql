-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: recruit
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `catId` varchar(8) NOT NULL,
  `catName` varchar(80) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`,`catId`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'cat00001','Development',1),(2,'cat00002','QA Testing',1),(3,'cat00003','Devops',1),(4,'cat00004','Fullstack',1),(5,'cat00005','Networking',1),(6,'cat00007','IT',0),(7,'cat00008','Support',1),(9,'cat00010','Training',1),(11,'CATYHBO3','HR',0),(12,'CATDDSLS','Admin',1),(13,'CATEWW9X','Servicenow',0),(14,'CATM1ASO','Chat support',0),(15,'CATNFSE7','IT',0),(16,'CATM3P42','HR',0),(17,'CAT49JQ0','IT',0),(18,'CAT36OZF','HR',0),(19,'CATGA67F','HR',0),(20,'CATDHH49','HR',0),(21,'CATB0V5O','IT',0),(22,'CATTH5WJ','HR',0),(23,'CATUFL0I','IT',0),(24,'CATH0HDD','HR',0),(25,'CATNRSUC','IT',0),(26,'CATDDF19','IT',0),(27,'CATLHOBF','HR',0),(28,'CAT3U459','Chat support',0),(29,'CATGH1KG','Servicenow',0),(30,'CATH7LFH','HR',0),(31,'CATVLIXC','IT',1),(32,'CAT3FEIZ','HR',1);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-21 21:27:20
