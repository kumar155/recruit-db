-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: recruit
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `candidatestatus`
--

DROP TABLE IF EXISTS `candidatestatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `candidatestatus` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `userId` varchar(45) NOT NULL,
  `jobId` varchar(45) NOT NULL,
  `type` int NOT NULL,
  `comments` mediumtext NOT NULL,
  `created` datetime NOT NULL,
  `updated` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `candidatestatus`
--

LOCK TABLES `candidatestatus` WRITE;
/*!40000 ALTER TABLE `candidatestatus` DISABLE KEYS */;
INSERT INTO `candidatestatus` VALUES (26,'5MIB9','POS17717',4,'','2023-12-09 19:36:59','GDS_Recruiter1'),(27,'KBA2A','POS57382',3,'having good technical skills moving further','2023-12-28 12:07:26','GDS_Recruiter1'),(28,'PYFP9','POS57382',4,'not good in tach stack','2023-12-09 19:36:59','GDS_Recruiter1'),(29,'5MIB9','POS57382',3,'offer letter issued','2023-12-09 19:36:59','GDS_Recruiter1'),(30,'5MIB9','POS19962',2,'interview round 2 passed','2023-12-09 19:36:59','GDS_Recruiter1'),(31,'5MIB9','POS29266',1,'null','2023-12-09 19:36:59','GDS_Recruiter1'),(32,'ZSYNH','POS60277',1,'null','2023-12-10 18:40:16','GDS_Recruiter1'),(33,'SZXNE','POS19962',1,'null','2023-12-11 16:20:18','GDS_Recruiter1'),(34,'ZSYNH','POS57382',3,'offered','2023-12-25 13:06:02','GDS_Recruiter1'),(35,'SZXNE','POS57382',4,'null','2023-12-11 16:20:18','GDS_Recruiter1'),(36,'ZSYNH','POS81065',0,'NA','2023-12-12 21:04:13','GDS_Recruiter1'),(37,'ZSYNH','POS84029',1,'moving further for interview process','2024-01-28 11:07:13','GDS_Recruiter1'),(38,'5MIB9','POS81065',1,'','2023-12-11 16:20:18','GDS_Recruiter1'),(39,'ZSYNH','POS62404',2,'null','2023-12-17 13:12:49','GDS_Recruiter1'),(40,'KBA2A','POS74966',1,'null','2023-12-17 13:12:49','GDS_Recruiter1'),(41,'5MIB9','POS74966',2,'null','2023-12-17 13:12:49','GDS_Recruiter1'),(42,'ZSYNH','POS74966',4,'null','2023-12-17 13:12:49','GDS_Recruiter1'),(43,'SZXNE','POS74966',1,'null','2023-12-17 13:12:49','GDS_Recruiter1'),(44,'ZSYNH','POS29266',4,'skills are not matched','2023-12-28 12:07:26','GDS_Recruiter1'),(45,'RHZFR','POS57382',0,'NA','2023-12-27 12:02:18','GDS_Recruiter1'),(46,'VWXYK','POS74966',0,'NA','2024-04-23 16:58:31','GDS_Recruiter1'),(47,'VWXYK','POS45189',0,'NA','2024-04-23 17:06:04','GDS_Recruiter1'),(48,'VWXYK','POS60277',0,'NA','2024-04-23 17:06:53','GDS_Recruiter1'),(49,'VWXYK','POS29266',0,'NA','2024-04-23 17:52:37','GDS_Recruiter1'),(50,'VWXYK','POS28118',0,'NA','2024-04-23 17:54:10','GDS_Recruiter1'),(51,'VWXYK','POS41040',0,'NA','2024-04-23 18:23:25','GDS_Recruiter1'),(52,'VWXYK','POS81065',0,'NA','2024-04-23 18:24:11','GDS_Recruiter1'),(53,'VWXYK','POS90114',0,'NA','2024-04-23 18:39:49','GDS_Recruiter1'),(54,'VWXYK','POS87791',0,'NA','2024-04-23 18:46:13','GDS_Recruiter1'),(55,'VWXYK','POS62404',0,'NA','2024-04-23 18:47:18','GDS_Recruiter1'),(56,'VWXYK','POS92305',0,'NA','2024-04-23 19:23:55','GDS_Recruiter1'),(57,'VWXYK','POS57382',0,'NA','2024-04-23 19:32:22','GDS_Recruiter1'),(58,'9DOKV','POS74966',0,'NA','2024-04-24 06:40:29','GDS_Recruiter1'),(59,'9DOKV','POS60277',0,'NA','2024-04-24 19:09:51','GDS_Recruiter1'),(60,'9DOKV','POS29266',0,'NA','2024-04-24 19:10:33','GDS_Recruiter1'),(61,'9DOKV','POS57382',0,'NA','2024-04-24 19:15:24','GDS_Recruiter1'),(62,'9DOKV','POS92305',0,'NA','2024-04-24 19:24:32','GDS_Recruiter1'),(63,'9DOKV','POS62404',0,'NA','2024-04-24 19:30:37','GDS_Recruiter1'),(64,'9DOKV','POS90114',0,'NA','2024-04-24 19:32:42','GDS_Recruiter1'),(65,'9DOKV','POS88972',0,'NA','2024-04-24 19:34:04','GDS_Recruiter1'),(66,'9DOKV','POS84029',0,'NA','2024-04-24 19:35:38','GDS_Recruiter1'),(67,'9DOKV','POS81065',0,'NA','2024-04-24 19:42:38','GDS_Recruiter1'),(68,'9DOKV','POS17717',0,'NA','2024-04-24 19:43:30','GDS_Recruiter1'),(69,'9DOKV','POS83230',0,'NA','2024-04-24 19:57:59','GDS_Recruiter1'),(70,'5MIB9','POS45189',0,'NA','2024-05-07 14:49:12','GDS_Recruiter1'),(71,'5MIB9','POS41040',0,'NA','2024-05-07 14:56:40','GDS_Recruiter1'),(72,'5MIB9','POS41040',0,'NA','2024-05-07 14:58:17','GDS_Recruiter1'),(73,'5MIB9','POS41040',0,'NA','2024-05-07 15:00:05','GDS_Recruiter1'),(74,'5MIB9','POS41040',0,'NA','2024-05-07 15:00:43','GDS_Recruiter1'),(75,'5MIB9','POS41040',0,'NA','2024-05-07 15:01:39','GDS_Recruiter1'),(76,'5MIB9','POS41040',0,'NA','2024-05-07 15:03:18','GDS_Recruiter1'),(77,'5MIB9','POS41040',0,'NA','2024-05-07 15:05:03','GDS_Recruiter1'),(78,'5MIB9','POS41040',0,'NA','2024-05-07 15:09:53','GDS_Recruiter1'),(79,'5MIB9','POS41040',0,'NA','2024-05-07 15:12:35','GDS_Recruiter1'),(80,'5MIB9','POS41040',0,'NA','2024-05-07 15:14:47','GDS_Recruiter1'),(81,'5MIB9','POS41040',0,'NA','2024-05-07 15:15:34','GDS_Recruiter1'),(82,'5MIB9','POS41040',0,'NA','2024-05-07 15:19:18','GDS_Recruiter1'),(83,'5MIB9','POS41040',0,'NA','2024-05-07 15:20:05','GDS_Recruiter1'),(84,'5MIB9','POS41040',0,'NA','2024-05-07 15:20:44','GDS_Recruiter1'),(85,'5MIB9','POS84029',0,'NA','2024-05-07 16:05:30','GDS_Recruiter1'),(86,'5MIB9','POS90114',0,'NA','2024-05-07 16:07:24','GDS_Recruiter1'),(87,'JUL50','POS57382',0,'NA','2024-05-07 16:13:06','GDS_Recruiter1'),(89,'JUL50','POS74966',0,'NA','2024-05-07 16:27:23','GDS_Recruiter1'),(90,'JUL50','POS60277',0,'NA','2024-05-07 17:41:04','GDS_Recruiter1'),(91,'JUL50','POS28118',0,'NA','2024-05-08 21:41:21','GDS_Recruiter1');
/*!40000 ALTER TABLE `candidatestatus` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-21 21:27:21
