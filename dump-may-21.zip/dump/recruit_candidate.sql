-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: recruit
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `candidate`
--

DROP TABLE IF EXISTS `candidate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `candidate` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` varchar(45) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `active` bit(1) DEFAULT NULL,
  `firstName` varchar(50) DEFAULT NULL,
  `lastName` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`,`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `candidate`
--

LOCK TABLES `candidate` WRITE;
/*!40000 ALTER TABLE `candidate` DISABLE KEYS */;
INSERT INTO `candidate` VALUES (1,'Test123','test@test.com','admin','2023-08-04 17:01:51',_binary '',NULL,NULL),(2,'Test123','test@test.com','admin','2023-08-04 17:22:39',_binary '',NULL,NULL),(3,'Test123','test@test.com','admin','2023-08-04 17:22:51',_binary '',NULL,NULL),(4,'AX1234','test@234','1111','2023-08-04 17:01:51',_binary '\0',NULL,NULL),(5,'AX1234','test@234','1111','2023-08-04 17:01:51',_binary '\0',NULL,NULL),(6,'VWE1A','sat@gmail.com','111111','2023-08-04 17:01:51',_binary '\0',NULL,NULL),(24,'7LSIL','test@test.com','testing','2023-08-04 17:01:51',_binary '\0',NULL,NULL),(25,'P0CFV','test@test.com','testing','2023-08-04 17:01:51',_binary '\0',NULL,NULL),(26,'EDAE7','test@test.com','Testing','2023-08-04 17:01:51',_binary '\0',NULL,NULL),(27,'K245E','test@test.com','testing','2023-08-04 17:01:51',_binary '\0',NULL,NULL),(28,'D29F4','user@test.com','testing','2023-08-04 17:01:51',_binary '\0',NULL,NULL),(29,'K0Z95','test@test.com','Testing','2023-08-04 17:01:51',_binary '\0',NULL,NULL),(34,'4QNFP','test@test.com','Testing@123','2023-09-05 17:11:16',_binary '\0',NULL,NULL),(35,'UEMLP','undefined','undefined','2023-09-16 12:25:34',_binary '\0',NULL,NULL),(36,'0Q69H','undefined','undefined','2023-09-16 12:25:34',_binary '\0',NULL,NULL),(37,'EQ1ZQ','undefined','undefined','2023-09-16 12:25:34',_binary '\0',NULL,NULL),(38,'AIESR','test@test.com','Test@1234','2023-09-16 12:25:34',_binary '\0',NULL,NULL),(39,'15NEP','test@test.com','Test@1234','2023-09-16 12:25:34',_binary '\0',NULL,NULL),(40,'QQAQ7','test@test.com','Test@1234','2023-09-16 12:38:22',_binary '\0',NULL,NULL),(41,'68MD5','test@test.com','Test@1234','2023-09-16 12:39:02',_binary '\0',NULL,NULL),(42,'2ITFP','test@test.com','Test@1234','2023-09-16 12:39:45',_binary '\0',NULL,NULL),(43,'CXCM7','test@test.com','Test@1234','2023-09-16 12:40:24',_binary '\0',NULL,NULL),(44,'S8KGR','test@test.com','Test@1234','2023-09-16 12:40:49',_binary '\0',NULL,NULL),(45,'WD1DQ','test@test.com','Test@1234','2023-09-16 12:41:23',_binary '\0',NULL,NULL),(46,'9B6RJ','test@test.com','Test@1234','2023-09-16 12:42:54',_binary '\0',NULL,NULL),(47,'4KHR6','test@test.com','Test@1234','2023-09-16 12:43:56',_binary '\0',NULL,NULL),(48,'YYTBC','test@test.com','Test@1234','2023-09-16 12:45:08',_binary '\0',NULL,NULL),(49,'WNF2D','test@test.com','Test@1234','2023-09-16 12:46:00',_binary '\0',NULL,NULL),(50,'67SEN','test@test.com','Test@1234','2023-09-16 12:47:33',_binary '\0',NULL,NULL),(51,'NEH1I','eve.holt@reqres.in','undefined','2023-09-16 18:17:46',_binary '\0',NULL,NULL),(52,'2KUCP','eve.holt@reqres.in','undefined','2023-09-16 18:17:46',_binary '\0',NULL,NULL),(53,'EDPE3','test@test.com','Testing@123','2023-09-17 16:18:34',_binary '\0',NULL,NULL),(54,'2MFF5','test@test.com','Testing@123','2023-09-17 16:18:34',_binary '\0',NULL,NULL),(55,'PYFP9','sathish.donthu@gmail.com','Testing@123','2023-09-19 12:50:28',_binary '\0','Satish','Kumar'),(56,'MMAGE','donthu@gmail.com','Test@123','2023-09-19 12:55:32',_binary '\0','Donthu',''),(57,'KBA2A','abc@abc.com','Testing@123','2023-09-19 14:19:29',_binary '\0','Donthu',''),(58,'SZXNE','abcd@abc.com','Testing@123','2023-09-19 14:19:29',_binary '\0','Ganesh',''),(59,'9U7GN','xyz@test.com','Testing@123','2023-09-19 17:08:12',_binary '\0','kumar',''),(60,'ZDPCG','sw@s.com','Testing@123','2023-09-19 17:08:12',_binary '\0','Swathi',''),(61,'2JAZS','testuser@test.com','Testing@123','2023-09-21 20:38:40',_binary '\0','Test User','test'),(62,'QSBJK','abcd@abc.com','Testing@123','2023-10-05 21:03:13',_binary '\0','test','test'),(63,'HXU9Z','bcd@abc.com','Testing@123','2023-10-05 21:03:13',_binary '\0','ABC','DEF'),(64,'5MIB9','donthu@gmail.com','Admin@123','2023-11-20 20:19:56',_binary '\0','Satish kumar',''),(65,'ZSYNH','sw@gmail.com','Ruddhu@123','2023-12-07 18:03:10',_binary '\0','abc','#)'),(66,'RHZFR','new@test.com','Admin@123','2023-12-27 11:55:05',_binary '\0','NewUser','new'),(67,'VWXYK','testapp@gmail.com','Admin@123','2024-02-08 18:44:40',_binary '\0','testing','app'),(68,'9DOKV','username@test.com','Admin@123','2024-04-24 06:27:44',_binary '\0','user name','password'),(69,'JUL50','dont@gmail.com','Admin@123','2024-05-05 08:43:05',_binary '\0','Donthu','kumar');
/*!40000 ALTER TABLE `candidate` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-21 21:27:21
