-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: recruit
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `candidateprofile`
--

DROP TABLE IF EXISTS `candidateprofile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `candidateprofile` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `userId` varchar(45) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `alternateEmail` varchar(45) DEFAULT NULL,
  `phone1` varchar(45) DEFAULT NULL,
  `phone2` varchar(45) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `location` varchar(45) DEFAULT NULL,
  `experience` varchar(45) DEFAULT NULL,
  `designation` varchar(45) DEFAULT NULL,
  `skills` varchar(1000) DEFAULT NULL,
  `topSkills` varchar(1000) DEFAULT NULL,
  `interestArea` varchar(45) DEFAULT NULL,
  `currentEmployer` varchar(45) DEFAULT NULL,
  `noticePeriod` varchar(45) DEFAULT NULL,
  `attachments` varchar(10000) DEFAULT NULL,
  `attachmentDateTime` datetime DEFAULT NULL,
  `github` varchar(105) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`,`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `candidateprofile`
--

LOCK TABLES `candidateprofile` WRITE;
/*!40000 ALTER TABLE `candidateprofile` DISABLE KEYS */;
INSERT INTO `candidateprofile` VALUES (1,'CKZJV',NULL,NULL,'undefined',NULL,'undefined','undefined','undefined',NULL,NULL,NULL,NULL,'undefined','undefined',NULL,NULL,NULL,'2023-08-04 17:01:51',NULL),(2,'Q2TII',NULL,NULL,'undefined',NULL,'undefined','undefined','undefined',NULL,NULL,NULL,NULL,'undefined','undefined',NULL,NULL,NULL,'2023-08-04 17:01:51',NULL),(5,'7LSIL',NULL,NULL,'9847384767',NULL,'TS','Hyderabad','6',NULL,NULL,NULL,NULL,'30','Google',NULL,NULL,NULL,'2023-08-04 17:01:51',NULL),(6,'P0CFV',NULL,NULL,'9487248736',NULL,'Telangana','Hyderabad','6','software engineer','Thailand,India,Vietnam,Turkey','Thailand,India,Vietnam,Turkey','Fullstack Developer','Google','30',NULL,NULL,'https://github.com/kumar155','2023-08-04 17:01:51',NULL),(7,'EDAE7',NULL,NULL,'9903987213',NULL,'TS','Hyderabad','6',NULL,NULL,NULL,NULL,'Google','30',NULL,NULL,NULL,'2023-08-04 17:01:51',NULL),(8,'K245E',NULL,NULL,'8784326436',NULL,'TS','Hyderabad','6',NULL,NULL,NULL,NULL,'Google','30',NULL,NULL,NULL,'2023-08-04 17:01:51',NULL),(9,'D29F4',NULL,NULL,'6862183612',NULL,'TS','Hyderabad','6',NULL,NULL,NULL,NULL,'Google','30',NULL,NULL,NULL,'2023-08-04 17:01:51',NULL),(10,'K0Z95',NULL,NULL,'4386423648',NULL,'TS','Hyderabad','6',NULL,NULL,NULL,NULL,'Google','30',NULL,NULL,NULL,'2023-08-04 17:01:51',NULL),(11,'E706A',NULL,NULL,'4673647823',NULL,'Telangana','Hyderabad','6',NULL,NULL,NULL,NULL,'Google','30',NULL,NULL,NULL,'2023-08-04 17:01:51',NULL),(12,'EVK8A',NULL,NULL,'6786436843',NULL,'Telangana','Hyderabad','6',NULL,NULL,NULL,NULL,'Google','30',NULL,NULL,NULL,'2023-08-04 17:01:51',NULL),(13,'WPTK9',NULL,NULL,'6231253612',NULL,'Telangana','Hyderabad','8',NULL,NULL,NULL,NULL,'Google','30',NULL,NULL,NULL,'2023-09-02 16:36:29',NULL),(14,'3Z4K0',NULL,NULL,'4242343242',NULL,'Telangana','Hyderabad','6','Senior software engineer','2,15','4,5','Fullstack Developer','Google','30',NULL,NULL,'https://github.com/kumar155','2023-09-02 16:36:29','2023-09-19 14:48:13'),(15,'4QNFP',NULL,NULL,'4324234233',NULL,'Virginia','Hyderabad','6',NULL,NULL,NULL,NULL,'Google','30',NULL,NULL,NULL,'2023-09-05 17:11:16',NULL),(16,'2MFF5',NULL,NULL,'6732867321',NULL,'Telangana','Hyderabad','6',NULL,NULL,NULL,NULL,'Google','30',NULL,NULL,NULL,'2023-09-17 16:18:34',NULL),(31,'PYFP9',NULL,NULL,'4323432432',NULL,'TS','Hyderabad','6','Senior software engineer','2,15,9','4,5,3,1','Fullstack Developer','Google','30',NULL,NULL,'https://github.com/kumar155','2023-09-19 17:08:12','2023-11-14 18:47:51'),(38,'9U7GN',NULL,NULL,'5675675675',NULL,'Virginia','Ashburn','10','Senior software engineer','4','3','Fullstack Developer','Netflix','30',NULL,NULL,'https://github.com/kumar155','2023-09-19 17:08:12','2023-10-05 20:35:39'),(44,'ZDPCG',NULL,NULL,'6546325463',NULL,'Washington','California','6','Senior software engineer','2,3,1','4,5,15','Fullstack Developer','Netflix','30',NULL,NULL,'https://github.com/kumar155','2023-09-19 17:59:41','2023-09-19 17:59:41'),(46,'2JAZS',NULL,NULL,'3512636126',NULL,'TS','Hyderabad','8','Senior software engineer','2,15,9,20','4,5,3,1','Fullstack Developer','Google','30',NULL,NULL,'https://github.com/kumar155','2023-09-21 20:38:40','2023-09-21 20:38:40'),(70,'ZDPCG',NULL,NULL,'6546325463',NULL,'Washington','California','6',NULL,NULL,NULL,NULL,'Netflix','30',NULL,NULL,NULL,'2023-10-05 20:35:39',NULL),(78,'QSBJK',NULL,NULL,'3265254632',NULL,'TS','Hyderabad','8','Senior software engineer','15,2,20','3,4,5','Fullstack Developer','Facebook','15',NULL,NULL,'https://github.com/kumar155','2023-10-05 21:03:13','2023-10-05 21:03:13'),(80,'HXU9Z',NULL,NULL,'4324324324',NULL,'TS','Hyderabad','6','Senior software engineer','4,5','3,15,2','Fullstack Developer','Facebook','30',NULL,NULL,'https://github.com/kumar155','2023-10-05 21:03:13','2023-10-05 21:03:13'),(87,'KBA2A',NULL,NULL,'5454545566',NULL,'TS','Hyderabad','6','Senior software engineer','15,1,9,4,5,8','3,20,2,40,39,35,38,36','Fullstack Developer','Google','30',NULL,NULL,'https://github.com/kumar155','2023-11-13 18:52:30','2023-11-16 14:47:26'),(88,'5MIB9',NULL,NULL,'5674565445',NULL,'TS','Hyderabad ','8','senior software engineer','9,20,37,39,40','4,5,3,1,15,2','full stack developer','serv','45','5MIB9-TT80D.pdf','2024-05-07 16:07:24','kumar155.github.com','2023-11-20 20:19:56','2024-05-07 16:07:24'),(89,'ZSYNH',NULL,NULL,'3234353542',NULL,'ts','hyderabad','6','SSE','3,15,21,2,38','4,9,20,5','full stack developer','123','23',NULL,NULL,'kumar155.github.com','2023-12-07 18:03:10','2024-05-03 22:34:09'),(90,'SZXNE',NULL,NULL,'4523363526',NULL,'TS','Hyderabad','6','Software Engineer','4,5,8','9,15,2','full stack developer','goog','30',NULL,NULL,'kumar155.github.com','2023-12-11 15:59:51','2023-12-11 16:20:18'),(91,'RHZFR',NULL,NULL,'7464743256',NULL,'TS','Hyderabad','7','Software Engineer','36,37,38,35,39,40','4,5,2,15,9','full stack developer','Google','30',NULL,NULL,'kumar155.github.com','2023-12-27 11:55:05','2023-12-27 11:55:05'),(92,'VWXYK',NULL,NULL,'5665646464',NULL,'TS','Hyderabad','8','Software Engineer','5','4','full stack developer','Goog','30','VWXYK-JGS5L.pdf','2024-04-23 19:22:32','kumar155.github.com','2024-04-23 16:14:46','2024-04-23 19:22:32'),(93,'9DOKV',NULL,NULL,'3545345556',NULL,'TS','Hyderabad','5','Software Engineer','5','4','full stack developer','GDS','30','9DOKV-VS1KG.pdf','2024-04-24 19:57:55','kumar155.github.com','2024-04-24 06:27:44','2024-04-24 19:59:31'),(94,'JUL50',NULL,NULL,'4324234234',NULL,'da','da','4','Software Engineer','5','4','full stack developer','Goog','30','JUL50-RE7RP.pdf','2024-05-08 21:41:21','kumar155.github.com','2024-05-05 08:56:07','2024-05-08 21:41:21');
/*!40000 ALTER TABLE `candidateprofile` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-21 21:27:21
