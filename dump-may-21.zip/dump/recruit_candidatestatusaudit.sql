-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: recruit
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `candidatestatusaudit`
--

DROP TABLE IF EXISTS `candidatestatusaudit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `candidatestatusaudit` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `userId` varchar(45) NOT NULL,
  `jobId` varchar(45) NOT NULL,
  `type` int NOT NULL,
  `comments` longtext,
  `created` datetime NOT NULL,
  `updatedBy` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `candidatestatusaudit`
--

LOCK TABLES `candidatestatusaudit` WRITE;
/*!40000 ALTER TABLE `candidatestatusaudit` DISABLE KEYS */;
INSERT INTO `candidatestatusaudit` VALUES (4,'5MIB9','POS17717',1,'profile looks good match for the position','2023-12-08 13:51:28','GDS_Recruiter1'),(5,'KBA2A','POS57382',1,'profile is selected for screening','2023-12-09 17:22:41','GDS_Recruiter1'),(6,'KBA2A','POS57382',2,'passed <br> 2nd round','2023-12-09 19:10:43','GDS_Recruiter1'),(7,'KBA2A','POS57382',2,'2nd round passed','2023-12-09 19:14:54','GDS_Recruiter1'),(8,'KBA2A','POS57382',2,'third round passed','2023-12-09 19:21:04','GDS_Recruiter1'),(9,'PYFP9','POS57382',4,'skills are not matched','2023-12-09 19:25:15','GDS_Recruiter1'),(10,'5MIB9','POS57382',1,'skills are matched hence moving profile to screening ','2023-12-09 19:44:01','GDS_Recruiter1'),(11,'5MIB9','POS57382',2,'screening passed','2023-12-09 19:44:46','GDS_Recruiter1'),(12,'5MIB9','POS57382',2,'interview round 1 passed','2023-12-09 19:45:26','GDS_Recruiter1'),(13,'5MIB9','POS57382',2,'interview round 2 passed','2023-12-09 19:45:39','GDS_Recruiter1'),(14,'5MIB9','POS57382',3,'offer letter issued','2023-12-09 19:46:03','GDS_Recruiter1'),(15,'PYFP9','POS57382',1,'skills are matched','2023-12-09 19:46:53','GDS_Recruiter1'),(16,'PYFP9','POS57382',2,'profile forwarded to interview based on screening','2023-12-09 20:03:33','GDS_Recruiter1'),(17,'5MIB9','POS19962',1,'moving to screening round','2023-12-09 20:07:04','GDS_Recruiter1'),(18,'5MIB9','POS19962',2,'screening passed hence moving to interview round','2023-12-09 20:07:39','GDS_Recruiter1'),(19,'5MIB9','POS19962',2,'interview round 1 passed','2023-12-09 20:07:57','GDS_Recruiter1'),(20,'5MIB9','POS19962',2,'interview round 2 passed','2023-12-09 20:08:15','GDS_Recruiter1'),(21,'5MIB9','POS29266',1,'null','2023-12-09 20:08:54','GDS_Recruiter1'),(22,'PYFP9','POS57382',4,'not good in tach stack','2023-12-09 20:10:08','GDS_Recruiter1'),(23,'5MIB9','POS17717',4,'','2023-12-09 20:34:20','GDS_Recruiter1'),(24,'ZSYNH','POS60277',1,'null','2023-12-11 11:36:22','GDS_Recruiter1'),(25,'ZSYNH','POS19962',0,NULL,'2023-12-11 12:42:29','GDS_Recruiter1'),(26,'ZSYNH','POS87791',0,NULL,'2023-12-11 13:48:26','GDS_Recruiter1'),(27,'ZSYNH','POS28118',0,NULL,'2023-12-11 13:55:51','GDS_Recruiter1'),(28,'ZSYNH','POS62404',0,NULL,'2023-12-11 14:01:55','GDS_Recruiter1'),(29,'ZSYNH','POS57382',0,NULL,'2023-12-11 14:15:27','GDS_Recruiter1'),(30,'SZXNE','POS74966',0,NULL,'2023-12-11 16:07:07','GDS_Recruiter1'),(31,'SZXNE','POS57382',0,NULL,'2023-12-11 16:10:15','GDS_Recruiter1'),(32,'SZXNE','POS45189',0,NULL,'2023-12-11 16:18:06','GDS_Recruiter1'),(33,'SZXNE','POS60277',0,NULL,'2023-12-11 16:19:17','GDS_Recruiter1'),(34,'SZXNE','POS19962',0,NULL,'2023-12-11 16:20:30','GDS_Recruiter1'),(35,'SZXNE','POS19962',1,'null','2023-12-11 16:22:22','GDS_Recruiter1'),(36,'ZSYNH','POS57382',1,'null','2023-12-11 16:23:04','GDS_Recruiter1'),(37,'SZXNE','POS57382',4,'null','2023-12-11 16:23:12','GDS_Recruiter1'),(38,'ZSYNH','POS81065',0,NULL,'2023-12-12 21:04:13','GDS_Recruiter1'),(39,'ZSYNH','POS84029',0,NULL,'2023-12-12 21:05:30','GDS_Recruiter1'),(40,'5MIB9','POS81065',1,'','2023-12-12 21:06:43','GDS_Recruiter1'),(41,'ZSYNH','POS62404',1,'null','2023-12-17 16:59:39','GDS_Recruiter1'),(42,'ZSYNH','POS62404',2,'null','2023-12-17 16:59:59','GDS_Recruiter1'),(43,'KBA2A','POS74966',1,'null','2023-12-17 18:43:49','GDS_Recruiter1'),(44,'5MIB9','POS74966',2,'null','2023-12-17 18:43:58','GDS_Recruiter1'),(45,'ZSYNH','POS74966',4,'null','2023-12-17 18:44:08','GDS_Recruiter1'),(46,'SZXNE','POS74966',1,'null','2023-12-17 18:44:16','GDS_Recruiter1'),(47,'ZSYNH','POS29266',0,NULL,'2023-12-25 13:02:38','GDS_Recruiter1'),(48,'ZSYNH','POS57382',2,'proceed for interview','2023-12-25 13:12:35','GDS_Recruiter1'),(49,'ZSYNH','POS57382',2,'good in technical skills, moving this for further consideration.','2023-12-25 13:13:25','GDS_Recruiter1'),(50,'ZSYNH','POS57382',3,'offered','2023-12-25 13:13:39','GDS_Recruiter1'),(51,'RHZFR','POS57382',0,NULL,'2023-12-27 12:02:18','GDS_Recruiter1'),(52,'KBA2A','POS57382',2,'','2023-12-28 21:42:21','GDS_Recruiter1'),(53,'KBA2A','POS57382',3,'having good technical skills moving further','2023-12-28 21:43:11','GDS_Recruiter1'),(54,'ZSYNH','POS29266',4,'skills are not matched','2023-12-28 22:34:46','GDS_Recruiter1'),(55,'ZSYNH','POS84029',1,'moving further for interview process','2024-02-01 21:40:57','GDS_Recruiter1'),(56,'VWXYK','POS74966',0,NULL,'2024-04-23 16:58:31','GDS_Recruiter1'),(57,'VWXYK','POS45189',0,NULL,'2024-04-23 17:06:04','GDS_Recruiter1'),(58,'VWXYK','POS60277',0,NULL,'2024-04-23 17:06:53','GDS_Recruiter1'),(59,'VWXYK','POS29266',0,NULL,'2024-04-23 17:52:37','GDS_Recruiter1'),(60,'VWXYK','POS28118',0,NULL,'2024-04-23 17:54:10','GDS_Recruiter1'),(61,'VWXYK','POS41040',0,NULL,'2024-04-23 18:23:25','GDS_Recruiter1'),(62,'VWXYK','POS81065',0,NULL,'2024-04-23 18:24:11','GDS_Recruiter1'),(63,'VWXYK','POS90114',0,NULL,'2024-04-23 18:39:49','GDS_Recruiter1'),(64,'VWXYK','POS87791',0,NULL,'2024-04-23 18:46:13','GDS_Recruiter1'),(65,'VWXYK','POS62404',0,NULL,'2024-04-23 18:47:18','GDS_Recruiter1'),(66,'VWXYK','POS92305',0,NULL,'2024-04-23 19:23:55','GDS_Recruiter1'),(67,'VWXYK','POS57382',0,NULL,'2024-04-23 19:32:22','GDS_Recruiter1'),(68,'9DOKV','POS74966',0,NULL,'2024-04-24 06:40:29','GDS_Recruiter1'),(69,'9DOKV','POS60277',0,NULL,'2024-04-24 19:09:51','GDS_Recruiter1'),(70,'9DOKV','POS29266',0,NULL,'2024-04-24 19:10:33','GDS_Recruiter1'),(71,'9DOKV','POS57382',0,NULL,'2024-04-24 19:15:24','GDS_Recruiter1'),(72,'9DOKV','POS92305',0,NULL,'2024-04-24 19:24:32','GDS_Recruiter1'),(73,'9DOKV','POS62404',0,NULL,'2024-04-24 19:30:37','GDS_Recruiter1'),(74,'9DOKV','POS90114',0,NULL,'2024-04-24 19:32:42','GDS_Recruiter1'),(75,'9DOKV','POS88972',0,NULL,'2024-04-24 19:34:04','GDS_Recruiter1'),(76,'9DOKV','POS84029',0,NULL,'2024-04-24 19:35:38','GDS_Recruiter1'),(77,'9DOKV','POS81065',0,NULL,'2024-04-24 19:42:38','GDS_Recruiter1'),(78,'9DOKV','POS17717',0,NULL,'2024-04-24 19:43:30','GDS_Recruiter1'),(79,'9DOKV','POS83230',0,NULL,'2024-04-24 19:57:59','GDS_Recruiter1'),(80,'5MIB9','POS45189',0,NULL,'2024-05-07 14:49:09','GDS_Recruiter1'),(81,'5MIB9','POS41040',0,NULL,'2024-05-07 14:56:40','GDS_Recruiter1'),(82,'5MIB9','POS41040',0,NULL,'2024-05-07 14:58:17','GDS_Recruiter1'),(83,'5MIB9','POS41040',0,NULL,'2024-05-07 15:00:05','GDS_Recruiter1'),(84,'5MIB9','POS41040',0,NULL,'2024-05-07 15:00:43','GDS_Recruiter1'),(85,'5MIB9','POS41040',0,NULL,'2024-05-07 15:01:39','GDS_Recruiter1'),(86,'5MIB9','POS41040',0,NULL,'2024-05-07 15:03:18','GDS_Recruiter1'),(87,'5MIB9','POS41040',0,NULL,'2024-05-07 15:05:03','GDS_Recruiter1'),(88,'5MIB9','POS41040',0,NULL,'2024-05-07 15:09:53','GDS_Recruiter1'),(89,'5MIB9','POS41040',0,NULL,'2024-05-07 15:12:35','GDS_Recruiter1'),(90,'5MIB9','POS41040',0,NULL,'2024-05-07 15:14:47','GDS_Recruiter1'),(91,'5MIB9','POS41040',0,NULL,'2024-05-07 15:15:34','GDS_Recruiter1'),(92,'5MIB9','POS41040',0,NULL,'2024-05-07 15:19:18','GDS_Recruiter1'),(93,'5MIB9','POS41040',0,NULL,'2024-05-07 15:20:05','GDS_Recruiter1'),(94,'5MIB9','POS41040',0,NULL,'2024-05-07 15:20:44','GDS_Recruiter1'),(95,'5MIB9','POS84029',0,NULL,'2024-05-07 16:05:30','GDS_Recruiter1'),(96,'5MIB9','POS90114',0,NULL,'2024-05-07 16:07:24','GDS_Recruiter1'),(97,'JUL50','POS57382',0,NULL,'2024-05-07 16:13:06','GDS_Recruiter1'),(98,'JUL50','POS57382',0,NULL,'2024-05-07 16:13:06','GDS_Recruiter1'),(99,'JUL50','POS74966',0,NULL,'2024-05-07 16:27:23','GDS_Recruiter1'),(100,'JUL50','POS60277',0,NULL,'2024-05-07 17:41:04','GDS_Recruiter1'),(101,'JUL50','POS28118',0,NULL,'2024-05-08 21:41:21','GDS_Recruiter1');
/*!40000 ALTER TABLE `candidatestatusaudit` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-21 21:27:21
